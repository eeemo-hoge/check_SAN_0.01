//FIRST OF ALL I CAN NOT ANY TAKE RESPONSIBILITY NO MATTER WHAT HAPPENENEND.
//Suvive today. Okay to be an electic. Facing to reality from front and suvive today. 
//I wanted to make medical stuff but, it takes too many time so, I quit. maybe next time.
//It originaly use this for myself but, if this exe file helps others to check SAN level and having rationality decision and see things ratinaliy, I'm glad.
//I do not gathering your personal info as code saying.
#include <stdio.h>
int main(){
    int sleep = 0;
    int vitamin = 0;
    int foods = 0;
    int bpm = 0;
    int SAN = 0;
    int goon = 0;
    int empty = 0;
    printf("> Do you got enough sleep this week? \n> Y = 1, N = 2\n");
    scanf("%d",&sleep);
    if(sleep == 1){
        SAN = SAN + 50;
        printf("> Your SAN is %d now\n",SAN);
    } else if(sleep == 2){
        SAN = SAN - 50;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");


    }
    printf("> Do u think u got enough vitamin this week? \n> Y = 1, N = 2\n");
    scanf("%d",&vitamin);
    if(vitamin == 1){
        SAN = SAN + 6;
        printf("> Your SAN is %d now\n",SAN);
    } else if(vitamin == 2){
        SAN = SAN - 6;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");
    }
    printf("> Do u think you ate healthy food this week?\n> Y = 1, N = 2\n");
    scanf("%d",&foods);
        if( foods == 1){
        SAN = SAN + 20;
        printf("> Your SAN is %d now\n",SAN);
    } else if(foods == 2){
        SAN = SAN - 10;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");
    }
    printf("> Do you gooned these days?\n> Y = 1, N = 2\n");
    scanf("%d",&goon);
    if(goon == 1){
        SAN = SAN -30;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");
    } else if(goon == 2){
        SAN = SAN + 15;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");
    }
    printf("> What is ur BPM in the minute.Do not count decimal point.\n>");
    printf("mesureed it by touch your neck, set timer 30 sec and multiple double)\n");
    scanf("%d",&bpm);
    if(bpm >= 50 && bpm <= 90){
        SAN = SAN + 0;
        printf("> Your SAN is %d now\n",SAN);
         printf("> type something or Ctrl + C and quit..");
        scanf("%d",&empty);
    } else if(bpm <= 55 || bpm >= 90 ){
        SAN = SAN - 10;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");
         printf("> type something or Ctrl + C and quit..");
        scanf("%d",&empty);
    }else{
        SAN = SAN - 21;
        printf("> Your SAN is %d now\n",SAN);
        printf("> Be careful\n");
        printf("> type something or Ctrl + C and quit..");
        scanf("%d",&empty);

    }
    return 0;
}